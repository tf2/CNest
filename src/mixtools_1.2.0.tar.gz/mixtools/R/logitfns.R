logit <- binomial()$linkfun
inv.logit <- binomial()$linkinv