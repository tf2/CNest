kern.C <- function (x, xi, h)
{
    (1+cos(pi*(xi-x)/h))/(2*h)
}
