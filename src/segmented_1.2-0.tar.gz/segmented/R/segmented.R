`segmented` <-
function(obj, seg.Z, psi, npsi, control=seg.control(), model=TRUE, ...){
            UseMethod("segmented")
            }
